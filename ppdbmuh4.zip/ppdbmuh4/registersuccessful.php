<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Berhasil! - PPDB SMP Muhammadiyah 4 Semarang</title>
    <meta http-equiv="refresh" content="5; url=dashboard/index.php">
    <link rel="icon" href="assets/images/logo/iconsmpmuh4.ico">
    <link rel="stylesheet" type="text/css" href="assets/materialize.min.css">
    <link rel="stylesheet" type="text/css" href="assets/animate.css">
    <style>
        /* fallback */
        @font-face {
            font-family: 'Material Icons';
            font-style: normal;
            font-weight: 400;
            src: url(assets/material-icons.woff2) format('woff2');
        }
        .material-icons {
            font-family: 'Material Icons';
            font-weight: normal;
            font-style: normal;
            font-size: 24px;
            line-height: 1;
            letter-spacing: normal;
            text-transform: none;
            display: inline-block;
            white-space: nowrap;
            word-wrap: normal;
            direction: ltr;
            -webkit-font-feature-settings: 'liga';
            -webkit-font-smoothing: antialiased;
        }
        body {
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        main {
            flex: 1 0 auto;
        }
    </style>
</head>
<body>
<div class="navbar-fixed">
    <nav class="white z-depth-2">
        <div class="nav-wrapper">
            <a class="brand-logo">&nbsp; <img src="assets/images/logo/logojadi2.png"
                    class="brand-logo" style="max-height:64px;" /></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a class="green-text darken-4"><b><i
                                class="material-icons left">create</i>REGISTRASI PPDB</b></a></li>
            </ul>
        </div>
    </nav>
</div>
<br/><br/><br/><br/>
<div class="container">
    <div class="row">
        <div class="col s12">
            <h1><b>REGISTRASI BERHASIL! <i class="material-icons medium green-text darken-4 animated infinite flash delay-0s">check</i></b></h1>
            <h5>Terimakasih atas registrasi anda, <br/>sesaat lagi akan diarahkan ke halaman login untuk melengkapi data pendaftaran anda.</h5>
        </div>
    </div>
    <div class="row">
        <div class="col s12">
            <div class="progress green darken-4">
                <div class="indeterminate" style="width: 100%"></div>
            </div>
        </div>
    </div>
</div>
<script src="assets/jquery-3.4.1.min.js"></script>
<script src="assets/materialize.min.js"></script>
<script type="text/javascript">
M.AutoInit();
</script>
</body>
</html>