<?php include('db.php');$dbconn = mysqli_connect($server, $username, $password, $database);date_default_timezone_set("Asia/Bangkok");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi PPDB - SMP Muhammadiyah 4 Semarang</title>
    <link rel="icon" href="assets/images/logo/iconsmpmuh4.ico">
    <link rel="stylesheet" type="text/css" href="assets/materialize.min.css">
    <style>
        /* fallback */
        @font-face {
            font-family: 'Material Icons';
            font-style: normal;
            font-weight: 400;
            src: url(assets/material-icons.woff2) format('woff2');
        }
        .material-icons {
            font-family: 'Material Icons';
            font-weight: normal;
            font-style: normal;
            font-size: 24px;
            line-height: 1;
            letter-spacing: normal;
            text-transform: none;
            display: inline-block;
            white-space: nowrap;
            word-wrap: normal;
            direction: ltr;
            -webkit-font-feature-settings: 'liga';
            -webkit-font-smoothing: antialiased;
        }
    </style>
</head>
<body>
<div class="navbar-fixed">
    <nav class="white z-depth-2">
        <div class="nav-wrapper">
            <a class="brand-logo">&nbsp; <img src="assets/images/logo/logojadi2.png"
                    class="brand-logo" style="max-height:64px;" /></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a class="green-text darken-4"><b><i
                                class="material-icons left">create</i>REGISTRASI PPDB</b></a></li>
            </ul>
        </div>
    </nav>
</div>
<div class="container">
    <div class="row">
        <div class="col s12 m12 l12">
            <h3 class="green-text darken-4"><b>REGISTRASI</b></h3><hr/>
        </div>
    </div>
    <div class="row">
        <div class="col s12 m12 l12">
            <h5>Untuk melakukan registrasi ppdb silahkan isi formulir di bawah ini:</h5>
        </div>
    </div>
    <form action="" method="post">
    <div class="row">
        <div class="col s12 m6 l6 input-field">
            <input type="text" id="input_nama" name="inputnama" required>
            <label for="input_nama">Nama Lengkap</label>
        </div>
        <div class="col s12 m6 l6 input-field">
            <input type="text" class="datepicker" id="input_tgllahir" name="inputtgllahir" required>
            <label for="input_tgllahir">Tanggal Lahir</label>
        </div>
        <div class="col s12 m6 l6 input-field">
            <input type="email" id="input_email" name="inputemail" required></input>
            <label for="input_email">Email</label>
        </div>
        <div class="col s12 m6 l6 input-field">
            <input type="text" id="input_telepon" name="inputtelepon" required></input>
            <label for="input_telepon">Telepon / HP</label>
        </div>
        <div class="col s12 m6 l6 input-field">
            <input type="password" id="input_password" name="inputpassword" required></input>
            <label for="input_password">Password</label>
        </div>
        <div class="col s12 m6 l6 input-field">
            <input type="password" id="input_password2" name="inputpassword2" required></input>
            <label for="input_password2">Konfirmasi Password</label>
        </div>
        <div class="col s12 m6 l6 input-field">
            <button type="submit" id="tbl_register" name="tblregister" class="btn btn-large waves-effect waves-light green darken-4"><b>DAFTAR</b></button>
        </div>
    </div>
    </form>
</div>
<footer class="green darken-4 white-text center center-align">
    &copy;2020 SMP MUHAMMADIYAH 4 SEMARANG &nbsp;&&nbsp; <a class="white-text" target="_blank" href="https://excellentcom.id/">DINARTECHSHARE-E</a>
</footer>
<script src="assets/jquery-3.4.1.min.js"></script>
<script src="assets/materialize.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#tbl_register").click(function () {
            var password = $("#input_password").val();
            var confirmPassword = $("#input_password2").val();
            if (password != confirmPassword) {
                alert('Password yang anda isikan tidak sama, harap cek kembali!');
                return false;
            }
            return true;
        });
    });
</script>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.datepicker');
    var instances = M.Datepicker.init(elems, options);
});

M.AutoInit();
</script>
</body>
</html>
<?php
if(isset($_POST['tblregister'])){
    $namalengkap    = mysqli_real_escape_string($dbconn, $_POST['inputnama']);
    $tanggallahir   = date("Y-m-d", strtotime(mysqli_real_escape_string($dbconn, $_POST['inputtgllahir'])));
    $email          = mysqli_real_escape_string($dbconn, $_POST['inputemail']);
    $telepon        = mysqli_real_escape_string($dbconn, $_POST['inputtelepon']);
    $password       = md5(mysqli_real_escape_string($dbconn, $_POST['inputpassword']));
    $cekemailreg    = mysqli_num_rows(mysqli_query($dbconn,"SELECT * FROM ppdb_users WHERE emails='$email'"));
    $namafolder = md5($email);
    if($cekemailreg > 0){
        echo '<script>alert("Maaf, Email yang anda masukkan telah terdaftar!")</script>';
    } else {
        $initregister = mysqli_query($dbconn,"INSERT INTO ppdb_users(dirfolder, date_register, passwords, emails, telp, nama_lengkap, tanggal_lahir) VALUES('$namafolder', NOW(), '$password','$email','$telepon','$namalengkap','$tanggallahir')");
        if($initregister){
            if(!file_exists('nggnesgrgster/'.$namafolder)) {
                mkdir('nggnesgrgster/'.$namafolder, 0777, true);
            }
            echo '<meta http-equiv="refresh" content="0; url=registersuccessful.php">';
        } else {
            echo '<script>alert("DB ERROR!")</script>';
        }
    }
}
?>
